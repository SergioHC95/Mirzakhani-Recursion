# Auto-enable local 'wp_recursion' when running from source without install.
# Does nothing if an installed package is already available.
try:
    import wp_recursion  # noqa: F401
except Exception:
    import sys, types, pathlib, importlib
    root = pathlib.Path(__file__).parent
    pkg = types.ModuleType("wp_recursion")
    # Make Python treat this as a package whose files live under ./src
    pkg.__path__ = [str(root / "src")]
    sys.modules["wp_recursion"] = pkg
    # Load the package __init__.py located at ./src/__init__.py
    importlib.import_module("wp_recursion.__init__")
